# UrsinaRemoteCar
Bu projede Python Ursina kodları kullanılmıştır.
